# Alex Morgan — Developer Portfolio

A responsive, animated portfolio website built with **HTML, CSS and vanilla JavaScript**. No frameworks or build tools are required.

## Features

- Responsive layout for phones, tablets and desktops
- Dark / light theme toggle (saved in local storage)
- Mobile navigation menu
- Scroll progress indicator
- Reveal-on-scroll animations
- Animated statistics
- Project category filters
- Contact form that prepares an email using `mailto:`
- Reduced-motion accessibility support
- Semantic HTML and accessible labels

## Project structure

```text
advanced-portfolio-website/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a browser.
3. For a better development workflow, open the folder in VS Code and use the Live Server extension.

There is no package installation step.

## Personalize it before publishing

Search the files for the sample identity **Alex Morgan** and replace it with your own details.

1. In `index.html`, change the page title, name, introduction, location, about section, skills, project descriptions, social links and email address.
2. In `script.js`, change `hello@example.com` in the contact form to the same real email address you want to receive enquiries at.
3. Replace the sample project cards with your own work and update their category values (`web` or `concept`) if needed.
4. Adjust the colors in the `:root` variables at the top of `style.css`.
5. Test the site at phone and desktop widths before publishing.

> The contact form does not send messages through a server. It opens the visitor's default email application. A real server-backed form requires a backend or a form service.

## Publish with GitHub Pages

1. Create a GitHub repository, for example `my-portfolio`.
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish your site. The Pages settings screen will show its public URL.

## Suggested next improvements

- Add real project screenshots and live project links.
- Add a custom favicon and social preview image.
- Connect a secure backend contact form if you need messages submitted without an email app.
- Add tests and check accessibility with keyboard navigation.

## License

You may adapt this starter project for your personal portfolio. Add a license file if you want to specify reuse terms for others.
